

export default async function handler(req, res) {
 
  //Return the content of the data file in json format
 
}